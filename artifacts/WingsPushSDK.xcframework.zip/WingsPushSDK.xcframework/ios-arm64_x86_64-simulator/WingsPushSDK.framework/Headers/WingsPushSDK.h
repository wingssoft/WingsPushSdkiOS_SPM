//
//  WingsPushSDK.h
//  WingsPushSDK
//
//  Created by Balashov Ilya on 04.12.2019.
//  Copyright © 2019 Balashov Ilya. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WingsPushSDK.
FOUNDATION_EXPORT double WingsPushSDKVersionNumber;

//! Project version string for WingsPushSDK.
FOUNDATION_EXPORT const unsigned char WingsPushSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WingsPushSDK/PublicHeader.h>


